#ifndef _PROCESADOR
#define _PROCESADOR
#include "ALU.h" //incluye al ALU
#include "Memoria.h"
#include "Convertidor.h"
#include "Registros.h"

class CPU{
public:
CPU();
ALU alu;
Memoria memoria;
ConvertidorHexa convertidor;
Registros registro;
ALU UnidadAriméticoLógica; //se crea un objeto ALU, el cual sera el cerebro aritmético que llevará el procedimiento de las instrucciones

private:
char PC[3]; //Program counter, vector que almacena hexadecimales
char IR[4]; //vector que almacena hexadecimales
//aquí después seguirían los registros A,B,C,D y los de lectura que serían objeto registros
void AsignarValorRegistros(); //método encargado de extraer de la memoria las instrucciones respectivas para colocarla en el PC y el IR
void readInstruction(); //método encargado de leer los registros para posteriormente enlazarlos con la respectiva instrucción para llevarla a cabo
void executeALUInstruction(); //método que se encarga de ejecutar la instrucción que se leyó en el método anterior, con ayuda del ALU
void printRegistros(); //método que mantiene imprimiendo lo que hay en los registros PC e IR después de llevar a cabo cada lectura y ejecución


};
#endif