#ifndef _CARGADOR
#define _CARGADOR
#include "Registros.h"

class MBR{
public:
MBR();
Registros registros;


private:
char registroMBR[4]; //vector que almacena hexadecimales
void setValorMBR(int,char); //asignar elemntos
char* getElementosMBR(int); //obtener elemento del vector celda creado
char* extraerRegistros(); //extrae los datos de los registros, funcionando como un bus de datos
void cargarMBR(); //función que se encarga de cargar desde la dirección de memoria
void guardarMBR(); //función que se encarga de guardar en cuerta dirección de memoria
//yo al MBR lo diseño como un vector char capaz de obtener datos, los cuales pueden provenir de la memporia, o bien guardar datos que desembocaran en la memoria

};
#endif