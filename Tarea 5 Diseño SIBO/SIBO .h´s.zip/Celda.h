#ifndef _CELDA
#define _CELDA

class Celda{
    public:
    Celda(char elementos[4]); // vector char de 4 elementos para almacenar el numero hexadecimal, útil para la construcción de cada celda de la memoria

    private:
    char celda[4]; //vector que almacena hexadecimales
    void setValor(int,char); //asignar elemntos
    char* getIndicePosicional(int); //obtener elemento del vector celda creado
    //vector de char hecho para almacenar los hexadecimales


};
#endif 