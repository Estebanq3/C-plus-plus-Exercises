#ifndef _SIBO
#define _SIBO

#include "Procesador.h"
#include "Memoria.h"
#include "MBR.h"

class Sibo{
    private:
    CPU procesador;
    Memoria memoria;
    MBR cargador;

    public:


	//el sibo seria el cerebro o el main general, el cual posee a todos los demás para su disposición

};

#endif