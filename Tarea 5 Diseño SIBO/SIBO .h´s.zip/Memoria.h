#ifndef _MEMORIA
#define _MEMORIA
#include "Celda.h"
#include "MBR.h"
//hilera de memoria donde se almacenan las instrucciones y los resultados de las mismas operaciones que realizará la computadora a lo largo de su ejecución

class Memoria{
private:
      Celda celda[4096]; //char de tamaño fijo, con objeto celda, cada celda es un vector char de 4 elementos, 4 casillas, para almacenar el hexadecimal
      MBR cargador;

public:
      Memoria();
      void setValorEnMemoria(int,char); //método para poder establecer un valor en el vector de memoria
      char* getValorDeMemoria(int); //método para poder obtener un valor del vector de memoria
      int getFilas(); //espacio total de almacentamiento, número de celdas
      void imprimir(); //imprimir el vector de memoria


};
#endif 