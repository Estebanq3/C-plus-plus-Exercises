#ifndef _CONVERTIDOR
#define _CONVERTIDOR

class ConvertidorHexa{
    public:
    ConvertidorHexa();

    private:
    int convertDecAHex(int decimal); //input de números que se reciben en decimal se pasan por este método para su respectiva conversión a hexadecimal
    char* convertDecBinario(int decimal);
    char* convertBinarioComplemento2(char*);
    char* convertirComplemento2aBinario(char*);
    char* convertHexADecimal(char); //método para invertir la conversión a hexadecimal para usuario

    int decimal;
};

#endif