#ifndef _REGISTROS
#define _REGISTROS

class Registros{
    public:
    Registros(char elementos[4]); // vector char de 4 elementos para almacenar el numero hexadecimal, útil para la construcción de cada celda de la memoria

    private:
    char registro[4]; //vector que almacena hexadecimales

    void setValor(int,char); //asignar elemntos
    char* getIndicePosicional(); //obtener elemento del vector creado
    //vector de char hecho para almacenar los hexadecimales

    


};
#endif 