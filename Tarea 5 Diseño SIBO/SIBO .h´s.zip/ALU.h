#ifndef _ALU
#define _ALU
#include "Registros.h"

class ALU{
public:
    ALU();
    Registros registros;
private:
      bool banderaNeutra; //bandera utilizada para saber si el valor de salida es neutro o 0
      bool banderaNegativa; //bandera utilizada para denotar si el valor de salida es negativo, si ambas son negativas es que el número es positivo

      ALU operator+(const ALU & );
      ALU operator-(const ALU & );
      ALU operator*( const ALU & );
      ALU operator/( const ALU & );
      ALU operatorModulo( const ALU & );
      ALU operatorMover( const ALU & ); //el método movimiento puede tener incidencia sobre las banderas
      ALU operatorJumperZero(const ALU & ); //salta si la bandera neutra está activa
      ALU operatorJummperNegative(const ALU & );//salta si la bandera negativa está encendida
      ALU operatorJumper(const ALU & ); //salto normal a cierta dirección de memoria
      ALU operatorStop(const ALU & ); //detiene la máquina


};
#endif