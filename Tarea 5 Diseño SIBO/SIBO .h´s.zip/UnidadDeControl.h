#ifndef _UNIDADDECONTROL
#define _UNIDADDECONTROL
#include "Procesador.h"
#include "Memoria.h"
class UnidadDeControl{
    private:
    CPU procesador;
    Memoria memoria;

    void loadRE(); //con regulaciones de control 
    void saveRE();
    void guardarEntrada();
    void controladorBandera(); //maneja las banderas ubicadas en el ALU    
    


    public:

};
#endif